class BankAccount {
    private long balance;

    synchronized void deposit(long amount) {
        balance += amount;
    }

    long getBalance() {
        return balance;
    }
}

class AccountWorker implements Runnable {
    private BankAccount account;
    private int times;
    private long amount;

    AccountWorker(BankAccount account, int times, long amount) {
        this.account = account;
        this.times = times;
        this.amount = amount;
    }

    public void run() {
        for (int i = 0; i < times; i++) {
            account.deposit(amount);
        }
        System.out.println(Thread.currentThread().getName() + " finished");
    }
}

public class AccountWorkerDemo {
    public static void main(String[] args) throws InterruptedException {
        BankAccount account = new BankAccount();
        Thread[] workers = new Thread[10];

        for (int i = 0; i < workers.length; i++) {
            workers[i] = new Thread(new AccountWorker(account, 1000, 1), "Worker-" + i);
            workers[i].start();
        }

        for (Thread worker : workers) {
            worker.join();
        }

        System.out.println("Final balance: " + account.getBalance());
    }
}
