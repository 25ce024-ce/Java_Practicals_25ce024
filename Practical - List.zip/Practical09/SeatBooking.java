class Cinema {
    private int seatsLeft = 5;
    private int booked = 0;

    synchronized boolean book() {
        if (seatsLeft > 0) {
            seatsLeft--;
            booked++;
            return true;
        }
        return false;
    }

    int getBooked() {
        return booked;
    }
}

public class SeatBooking {
    public static void main(String[] args) throws InterruptedException {
        Cinema cinema = new Cinema();
        Thread[] people = new Thread[10];

        for (int i = 0; i < people.length; i++) {
            people[i] = new Thread(() -> {
                if (cinema.book()) {
                    System.out.println(Thread.currentThread().getName() + " booked a seat");
                }
            });
            people[i].start();
        }

        for (Thread person : people) {
            person.join();
        }

        System.out.println("Seats booked: " + cinema.getBooked());
    }
}
