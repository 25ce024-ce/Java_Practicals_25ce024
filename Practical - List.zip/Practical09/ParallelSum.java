public class ParallelSum {
    static long total = 0;

    static synchronized void add(long value) {
        total += value;
    }

    public static void main(String[] args) throws InterruptedException {
        Thread[] threads = new Thread[4];

        for (int i = 0; i < threads.length; i++) {
            int start = i * 1000 + 1;
            int end = start + 999;

            threads[i] = new Thread(() -> {
                long localSum = 0;
                for (int n = start; n <= end; n++) {
                    localSum += n;
                }
                add(localSum);
            });

            threads[i].start();
        }

        for (Thread thread : threads) {
            thread.join();
        }

        System.out.println("Total: " + total);
    }
}
