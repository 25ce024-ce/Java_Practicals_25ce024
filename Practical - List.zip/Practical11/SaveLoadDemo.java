import java.io.*;

class Product implements Serializable {
    private static final long serialVersionUID = 1L;
    String name;
    transient String temporaryNote;
    double price;

    Product(String name, String temporaryNote, double price) {
        this.name = name;
        this.temporaryNote = temporaryNote;
        this.price = price;
    }
}

public class SaveLoadDemo {
    public static void main(String[] args) throws Exception {
        Product[] products = {
            new Product("Book", "temporary", 120),
            new Product("Pen", "not saved", 20)
        };

        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("products.dat"))) {
            out.writeObject(products);
        }

        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream("products.dat"))) {
            Product[] loaded = (Product[]) in.readObject();
            for (Product product : loaded) {
                System.out.println(product.name + " " + product.price + " " + product.temporaryNote);
            }
        }
    }
}
