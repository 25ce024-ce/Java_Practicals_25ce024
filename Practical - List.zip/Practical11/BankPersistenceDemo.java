import java.io.*;
import java.nio.file.*;
import java.util.*;

class SavedAccount implements Serializable {
    private static final long serialVersionUID = 1L;
    String number;
    long balance;

    SavedAccount(String number, long balance) {
        this.number = number;
        this.balance = balance;
    }

    public String toString() {
        return number + " | " + balance;
    }
}

public class BankPersistenceDemo {
    public static void main(String[] args) throws Exception {
        SavedAccount[] accounts = {
            new SavedAccount("AC0001", 5000),
            new SavedAccount("AC0002", 2500)
        };
        Path file = Paths.get("accounts.dat");

        try (ObjectOutputStream out = new ObjectOutputStream(Files.newOutputStream(file))) {
            out.writeObject(accounts);
        }

        SavedAccount[] loaded;
        try (ObjectInputStream in = new ObjectInputStream(Files.newInputStream(file))) {
            loaded = (SavedAccount[]) in.readObject();
        }

        for (SavedAccount account : loaded) {
            System.out.println(account);
        }

        Path log = Paths.get("transactions.log");
        Files.writeString(log, "DEPOSIT AC0001 500\nWITHDRAW AC0002 200\n",
                StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        System.out.println("Transaction log saved");
    }
}
