import java.nio.file.*;
import java.io.*;
import java.util.stream.*;

public class LogAnalyzer {
    public static void main(String[] args) throws IOException {
        Path folder = Paths.get("samplelogs");
        Files.createDirectories(folder);
        Files.writeString(folder.resolve("one.txt"), "login successful\nerror found\nlogin again\n");
        Files.writeString(folder.resolve("two.txt"), "another error\nall good\n");

        String keyword = "error";
        int totalLines = 0;
        int matches = 0;

        try (DirectoryStream<Path> stream = Files.newDirectoryStream(folder, "*.txt")) {
            for (Path path : stream) {
                long size = Files.size(path);
                System.out.println(path.getFileName() + " size: " + size);
                try (BufferedReader reader = Files.newBufferedReader(path)) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        totalLines++;
                        if (line.toLowerCase().contains(keyword)) {
                            matches++;
                        }
                    }
                }
            }
        }

        System.out.println("Total lines: " + totalLines);
        System.out.println("Lines containing keyword: " + matches);
    }
}
