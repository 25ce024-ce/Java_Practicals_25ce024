import java.nio.file.*;
import java.nio.file.attribute.*;
import java.io.*;

public class FolderReport {
    public static void main(String[] args) throws IOException {
        Path folder = Paths.get(".");
        Path report = Paths.get("folder-report.txt");

        try (BufferedWriter writer = Files.newBufferedWriter(report)) {
            try (var paths = Files.walk(folder, 2)) {
                paths.filter(Files::isRegularFile).forEach(path -> {
                    try {
                        BasicFileAttributes data = Files.readAttributes(path, BasicFileAttributes.class);
                        writer.write(path.getFileName() + " | " + data.size() + " bytes | " + data.lastModifiedTime());
                        writer.newLine();
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                });
            }
        }

        System.out.println("Report created");
    }
}
