class Fraction {
    private int num;
    private int den;

    // Greatest common divisor via Euclid's algorithm
    private static int findGcd(int a, int b) {
        while (b != 0) {
            int temp = b;
            b = a % b;
            a = temp;
        }
        return (a < 0) ? -a : a;
    }

    public Fraction(int num, int den) {
        int commonDivisor = findGcd(num, den);
        this.num = num / commonDivisor;
        this.den = den / commonDivisor;
    }

    public String toString() {
        return num + "/" + den;
    }

    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Fraction other = (Fraction) obj;
        return this.num == other.num && this.den == other.den;
    }

    public int hashCode() {
        return 31 * num + den;
    }
}

public class FractionDriver {
    public static void main(String[] args) {
        Fraction f1 = new Fraction(1, 2);
        Fraction f2 = new Fraction(2, 4);
        Fraction f3 = new Fraction(3, 6);

        System.out.println("f1 prints: " + f1);
        System.out.println("f2 prints: " + f2);
        System.out.println("f1 equals f2: " + f1.equals(f2));
        System.out.println("f2 equals f3: " + f2.equals(f3));
    }
}