class Customer implements Cloneable {
    private String name;
    private Address address;

    // Static nested class
    public static class Address {
        private String line;
        private String city;
        private String pincode;

        public Address(String line, String city, String pincode) {
            this.line = line;
            this.city = city;
            this.pincode = pincode;
        }

        public String getLine() { return line; }
        public String getCity() { return city; }
        public String getPincode() { return pincode; }

        public String toString() {
            return line + ", " + city + " (" + pincode + ")";
        }
    }

    public Customer(String name, Address address) {
        this.name = name;
        this.address = address;
    }

    public String getName() { return name; }
    public Address getAddress() { return address; }

    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
}

class Account {
    private final String accountNumber;
    private String ownerName;
    private long balance;

    public Account(String accountNumber, String ownerName, long balance) {
        this.accountNumber = accountNumber;
        this.ownerName = ownerName;
        this.balance = balance;
    }

    public String toString() {
        return accountNumber + " | " + ownerName + " | " + balance;
    }

    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Account other = (Account) obj;
        return this.accountNumber.equals(other.accountNumber);
    }

    public int hashCode() {
        return accountNumber.hashCode();
    }
}

public class MiniBankDriver {
    public static void main(String[] args) throws Exception {
        Account a1 = new Account("AC0001", "Riya", 4000);
        Account a2 = new Account("AC0001", "Riya Duplicate", 9000);

        System.out.println("Printing a1: " + a1);
        System.out.println("a1 equals a2: " + a1.equals(a2));

        Customer.Address addr = new Customer.Address("MG Road", "Vadodara", "390001");
        Customer customer = new Customer("Riya", addr);
        Customer cloned = (Customer) customer.clone();

        System.out.println("Cloned: " + cloned.getName() + " from " + cloned.getAddress());

        Object ref = a1;
        if (ref instanceof Account) {
            System.out.println("Type confirmation: ref is indeed an Account instance.");
        }
    }
}