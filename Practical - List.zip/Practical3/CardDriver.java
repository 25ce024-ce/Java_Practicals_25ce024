class Card {
    private String rank;
    private String suit;

    public Card(String rank, String suit) {
        this.rank = rank;
        this.suit = suit;
    }

    public String toString() {
        return rank + " of " + suit;
    }

    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Card other = (Card) obj;
        return this.rank.equals(other.rank) && this.suit.equals(other.suit);
    }

    public int hashCode() {
        return rank.hashCode() * 31 + suit.hashCode();
    }
}

public class CardDriver {
    public static void main(String[] args) {
        Card[] hand = new Card[5];
        Card[] incoming = {
            new Card("Ace", "Spades"),
            new Card("10", "Hearts"),
            new Card("King", "Diamonds"),
            new Card("Ace", "Spades")
        };

        int filled = 0;
        for (int i = 0; i < incoming.length; i++) {
            boolean duplicate = false;
            for (int j = 0; j < filled; j++) {
                if (incoming[i].equals(hand[j])) {
                    duplicate = true;
                    System.out.println("Duplicate found: " + incoming[i]);
                    break;
                }
            }
            if (!duplicate) {
                hand[filled] = incoming[i];
                filled++;
            }
        }
    }
}