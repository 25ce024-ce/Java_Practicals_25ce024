public class ParkingLot {
    private int twoWheelers = 0;
    private int fourWheelers = 0;
    private final int twoCap;
    private final int fourCap;
    private static long revenue = 0;

    public ParkingLot(int twoCap, int fourCap) {
        this.twoCap = twoCap;
        this.fourCap = fourCap;
    }

    public void park(String vehicleType) {
        if (vehicleType.equalsIgnoreCase("two")) {
            if (twoWheelers < twoCap) {
                twoWheelers++;
                revenue = revenue + 20;
                System.out.println("Parked 2-wheeler. Collected 20.");
            } else {
                System.out.println("Full");
            }
        } else if (vehicleType.equalsIgnoreCase("four")) {
            if (fourWheelers < fourCap) {
                fourWheelers++;
                revenue = revenue + 40;
                System.out.println("Parked 4-wheeler. Collected 40.");
            } else {
                System.out.println("Full");
            }
        }
    }

    public void leave(String vehicleType) {
        if (vehicleType.equalsIgnoreCase("two") && twoWheelers > 0) {
            twoWheelers--;
        } else if (vehicleType.equalsIgnoreCase("four") && fourWheelers > 0) {
            fourWheelers--;
        }
    }

    public static void main(String[] args) {
        ParkingLot lot = new ParkingLot(2, 1);

        lot.park("two");
        lot.park("two");
        lot.park("two"); // Rejected
        lot.park("four");
        lot.park("four"); // Rejected

        lot.leave("two");
        lot.park("two"); // Accepted

        System.out.println("Final total revenue: " + ParkingLot.revenue);
    }
}