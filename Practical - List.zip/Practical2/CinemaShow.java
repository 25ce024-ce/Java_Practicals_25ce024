public class CinemaShow {
    private String title;
    private int seatsAvailable;
    private final int capacity;
    private static int totalBooked = 0;

    public CinemaShow(String title, int capacity) {
        this.title = title;
        this.capacity = capacity;
        this.seatsAvailable = capacity;
    }

    public CinemaShow(String title) {
        this(title, 100);
    }

    public boolean book(int count) {
        if (count <= seatsAvailable) {
            seatsAvailable = seatsAvailable - count;
            totalBooked = totalBooked + count;
            return true;
        }
        return false;
    }

    public void cancel(int count) {
        seatsAvailable = seatsAvailable + count;
        if (seatsAvailable > capacity) {
            seatsAvailable = capacity;
        }
    }

    public int getSeatsAvailable() {
        return seatsAvailable;
    }

    public static int getTotalBooked() {
        return totalBooked;
    }

    public static void main(String[] args) {
        CinemaShow show = new CinemaShow("Interstellar", 40);

        System.out.println("Book 25: " + show.book(25) + " | Seats Left: " + show.getSeatsAvailable());
        System.out.println("Book 20: " + show.book(20) + " | Seats Left: " + show.getSeatsAvailable());

        show.cancel(5);
        System.out.println("After cancel 5 | Seats Left: " + show.getSeatsAvailable());
        System.out.println("Global Booked Across Shows: " + CinemaShow.getTotalBooked());
    }
}