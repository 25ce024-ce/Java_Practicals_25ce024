import java.util.*;

class Task {
    private String name;

    Task(String name) {
        this.name = name;
    }

    public String toString() {
        return name;
    }
}

class TaskService {
    private ArrayList<Task> tasks = new ArrayList<>();

    void addTask(String name) {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Task name cannot be empty");
        }
        tasks.add(new Task(name));
    }

    int count() {
        return tasks.size();
    }

    ArrayList<Task> getTasks() {
        return new ArrayList<>(tasks);
    }
}

public class SimpleLayeredApp {
    public static void main(String[] args) {
        TaskService service = new TaskService();
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("1. Add task");
            System.out.println("2. Show tasks");
            System.out.println("3. Count tasks");
            System.out.println("4. Exit");
            System.out.print("Choose: ");
            String choice = sc.nextLine();

            try {
                if (choice.equals("1")) {
                    System.out.print("Task name: ");
                    service.addTask(sc.nextLine());
                } else if (choice.equals("2")) {
                    System.out.println(service.getTasks());
                } else if (choice.equals("3")) {
                    System.out.println("Count: " + service.count());
                } else if (choice.equals("4")) {
                    break;
                } else {
                    throw new IllegalArgumentException("Invalid choice");
                }
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
            }
        }

        sc.close();
    }
}
