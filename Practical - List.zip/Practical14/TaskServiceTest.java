import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class TaskServiceTest {
    @Test
    void addingTaskIncreasesCount() {
        TaskService service = new TaskService();
        service.addTask("Study Java");
        assertEquals(1, service.count());
    }

    @Test
    void blankTaskIsRejected() {
        TaskService service = new TaskService();
        assertThrows(IllegalArgumentException.class, () -> service.addTask(""));
    }

    @Test
    void addingTwoTasksGivesCountTwo() {
        TaskService service = new TaskService();
        service.addTask("Read");
        service.addTask("Practice");
        assertEquals(2, service.count());
    }
}
