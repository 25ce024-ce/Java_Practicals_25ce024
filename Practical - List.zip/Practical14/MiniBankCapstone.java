import java.util.*;

class MiniAccount {
    private final String number;
    private String owner;
    private long balance;

    MiniAccount(String number, String owner, long balance) {
        this.number = number;
        this.owner = owner;
        this.balance = balance;
    }

    String getNumber() {
        return number;
    }

    String getOwner() {
        return owner;
    }

    synchronized long getBalance() {
        return balance;
    }

    synchronized void deposit(long amount) {
        if (amount <= 0) {
            throw new IllegalArgumentException("Amount must be positive");
        }
        balance += amount;
    }

    synchronized void withdraw(long amount) {
        if (amount <= 0) {
            throw new IllegalArgumentException("Amount must be positive");
        }
        if (amount > balance) {
            throw new IllegalArgumentException("Insufficient funds");
        }
        balance -= amount;
    }

    public String toString() {
        return number + " | " + owner + " | " + getBalance();
    }
}

class BankService {
    private Map<String, MiniAccount> accounts = new HashMap<>();
    private ArrayList<String> history = new ArrayList<>();

    MiniAccount openAccount(String owner, long openingBalance) {
        String number = "AC" + String.format("%04d", accounts.size() + 1);
        MiniAccount account = new MiniAccount(number, owner, openingBalance);
        accounts.put(number, account);
        history.add("OPEN " + number);
        return account;
    }

    void deposit(String number, long amount) {
        MiniAccount account = find(number);
        account.deposit(amount);
        history.add("DEPOSIT " + number + " " + amount);
    }

    void withdraw(String number, long amount) {
        MiniAccount account = find(number);
        account.withdraw(amount);
        history.add("WITHDRAW " + number + " " + amount);
    }

    void transfer(String from, String to, long amount) {
        MiniAccount source = find(from);
        MiniAccount target = find(to);
        source.withdraw(amount);
        target.deposit(amount);
        history.add("TRANSFER " + from + " " + to + " " + amount);
    }

    MiniAccount find(String number) {
        MiniAccount account = accounts.get(number);
        if (account == null) {
            throw new IllegalArgumentException("Account not found");
        }
        return account;
    }

    void listAccounts() {
        for (MiniAccount account : accounts.values()) {
            System.out.println(account);
        }
    }

    void statement() {
        for (String item : history) {
            System.out.println(item);
        }
    }
}

public class MiniBankCapstone {
    public static void main(String[] args) {
        BankService bank = new BankService();
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("\n1. Open account");
            System.out.println("2. Deposit");
            System.out.println("3. Withdraw");
            System.out.println("4. Transfer");
            System.out.println("5. List accounts");
            System.out.println("6. Statement");
            System.out.println("7. Exit");
            System.out.print("Choose: ");
            String choice = sc.nextLine();

            try {
                if (choice.equals("1")) {
                    System.out.print("Owner name: ");
                    String owner = sc.nextLine();
                    System.out.print("Opening balance: ");
                    long amount = Long.parseLong(sc.nextLine());
                    System.out.println("Created: " + bank.openAccount(owner, amount).getNumber());
                } else if (choice.equals("2")) {
                    System.out.print("Account number: ");
                    String number = sc.nextLine();
                    System.out.print("Amount: ");
                    bank.deposit(number, Long.parseLong(sc.nextLine()));
                    System.out.println("Deposit successful");
                } else if (choice.equals("3")) {
                    System.out.print("Account number: ");
                    String number = sc.nextLine();
                    System.out.print("Amount: ");
                    bank.withdraw(number, Long.parseLong(sc.nextLine()));
                    System.out.println("Withdrawal successful");
                } else if (choice.equals("4")) {
                    System.out.print("From account: ");
                    String from = sc.nextLine();
                    System.out.print("To account: ");
                    String to = sc.nextLine();
                    System.out.print("Amount: ");
                    bank.transfer(from, to, Long.parseLong(sc.nextLine()));
                    System.out.println("Transfer successful");
                } else if (choice.equals("5")) {
                    bank.listAccounts();
                } else if (choice.equals("6")) {
                    bank.statement();
                } else if (choice.equals("7")) {
                    break;
                } else {
                    System.out.println("Invalid choice");
                }
            } catch (IllegalArgumentException e) {
                System.out.println("Error: " + e.getMessage());
            }
        }

        sc.close();
    }
}
