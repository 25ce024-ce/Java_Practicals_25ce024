class BankException extends Exception {
    BankException(String message) {
        super(message);
    }
}

class InsufficientFundsException extends BankException {
    private long shortfall;

    InsufficientFundsException(long shortfall) {
        super("Withdrawal failed: short by " + shortfall);
        this.shortfall = shortfall;
    }

    long getShortfall() {
        return shortfall;
    }
}

class InvalidAmountException extends BankException {
    InvalidAmountException(String message) {
        super(message);
    }
}

class AccountNotFoundException extends BankException {
    AccountNotFoundException(String message) {
        super(message);
    }
}

class SimpleAccount {
    private long balance;

    SimpleAccount(long balance) {
        this.balance = balance;
    }

    void deposit(long amount) throws InvalidAmountException {
        if (amount <= 0) {
            throw new InvalidAmountException("Deposit amount must be positive");
        }
        balance += amount;
    }

    void withdraw(long amount) throws InsufficientFundsException, InvalidAmountException {
        if (amount <= 0) {
            throw new InvalidAmountException("Withdrawal amount must be positive");
        }
        if (amount > balance) {
            throw new InsufficientFundsException(amount - balance);
        }
        balance -= amount;
    }

    long getBalance() {
        return balance;
    }
}

class BankResource implements AutoCloseable {
    public void close() {
        System.out.println("Bank resource closed");
    }
}

public class BankExceptionDemo {
    public static void main(String[] args) {
        SimpleAccount account = new SimpleAccount(1000);

        try {
            account.withdraw(5000);
        } catch (InsufficientFundsException e) {
            System.out.println(e.getMessage());
        } catch (InvalidAmountException e) {
            System.out.println(e.getMessage());
        } finally {
            System.out.println("Current balance: " + account.getBalance());
        }

        try (BankResource resource = new BankResource()) {
            System.out.println("Processing bank request");
        }
    }
}
