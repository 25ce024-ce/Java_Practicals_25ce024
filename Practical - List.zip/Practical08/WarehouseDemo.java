import java.util.*;

class OutOfStockException extends Exception {
    int shortfall;

    OutOfStockException(int shortfall) {
        super("Not enough stock. Short by " + shortfall);
        this.shortfall = shortfall;
    }
}

class InvalidQuantityException extends Exception {
    InvalidQuantityException(String message) {
        super(message);
    }
}

class Warehouse {
    private int stock;

    Warehouse(int stock) {
        this.stock = stock;
    }

    void issue(String item, int qty) throws OutOfStockException, InvalidQuantityException {
        if (qty <= 0) {
            throw new InvalidQuantityException("Quantity must be positive");
        }
        if (qty > stock) {
            throw new OutOfStockException(qty - stock);
        }
        stock -= qty;
        System.out.println(qty + " " + item + " issued. Stock left: " + stock);
    }
}

public class WarehouseDemo {
    public static void main(String[] args) {
        Warehouse warehouse = new Warehouse(10);
        int[] requests = {3, 12, 0, 4};

        for (int qty : requests) {
            try {
                warehouse.issue("boxes", qty);
            } catch (OutOfStockException | InvalidQuantityException e) {
                System.out.println(e.getMessage());
            }
        }
    }
}
