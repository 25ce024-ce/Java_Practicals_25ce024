class MyResource implements AutoCloseable {
    public void use() {
        System.out.println("Resource is being used");
    }

    public void close() {
        System.out.println("Resource closed");
    }
}

public class ResourceDemo {
    public static void main(String[] args) {
        try (MyResource resource = new MyResource()) {
            resource.use();
            throw new RuntimeException("Something went wrong");
        } catch (RuntimeException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
