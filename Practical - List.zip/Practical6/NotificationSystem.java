interface Urgent {}

interface Notifier {
    void send(String message);
}

public class NotificationSystem {
    public static void main(String[] args) {
        // Lambda-based basic notifier
        Notifier emailNotifier = msg -> System.out.println("[EMAIL] " + msg);

        // Class implementing both Notifier and the Urgent marker
        class UrgentSmsNotifier implements Notifier, Urgent {
            public void send(String msg) {
                System.out.println("[URGENT SMS] " + msg);
            }
        }

        Notifier smsNotifier = new UrgentSmsNotifier();
        Notifier[] list = { emailNotifier, smsNotifier };
        String broadcast = "Server memory warning!";

        for (int i = 0; i < list.length; i++) {
            if (list[i] instanceof Urgent) {
                list[i].send(broadcast);
                list[i].send(broadcast); // repeat for urgent senders
            } else {
                list[i].send(broadcast);
            }
        }
    }
}