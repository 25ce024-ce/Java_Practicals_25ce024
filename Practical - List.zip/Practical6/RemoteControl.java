interface Switchable {
    void on();
    void off();

    default void toggle(boolean isOn) {
        if (isOn) {
            off();
        } else {
            on();
        }
    }
}

class Fan implements Switchable {
    public void on() { System.out.println("Fan on."); }
    public void off() { System.out.println("Fan off."); }
}

class Light implements Switchable {
    public void on() { System.out.println("Light on."); }
    public void off() { System.out.println("Light off."); }
}

interface DeviceRule {
    boolean canTurnOn(Switchable device, int hour);
}

public class RemoteControl {
    public static void main(String[] args) {
        Switchable[] devices = { new Fan(), new Light() };
        for (int i = 0; i < devices.length; i++) {
            devices[i].toggle(false);
        }

        // 1. Anonymous class implementation
        DeviceRule businessHours = new DeviceRule() {
            public boolean canTurnOn(Switchable dev, int hour) {
                return hour >= 9 && hour <= 17;
            }
        };

        // 2. Lambda expression implementation
        DeviceRule nightRule = (dev, hour) -> (hour >= 18 || hour <= 6);

        System.out.println("Allowed at 10 AM (Business Hours): " + businessHours.canTurnOn(devices[0], 10));
        System.out.println("Allowed at 10 AM (Night Rule): " + nightRule.canTurnOn(devices[0], 10));
    }
}