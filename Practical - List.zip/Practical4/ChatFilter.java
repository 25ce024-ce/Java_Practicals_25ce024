import java.util.Scanner;

public class ChatFilter {
    public static void main(String[] args) {
        String[] logs = {
            "10:05 alice Hello there",
            "10:07 bob How are you doing?",
            "malformed_line_sample",
            "10:10 charlie hello everyone"
        };

        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter search keyword: ");
        String term = scanner.next().toLowerCase();

        int matches = 0;
        StringBuilder builder = new StringBuilder();

        for (int i = 0; i < logs.length; i++) {
            String[] segments = logs[i].split(" ", 3);
            if (segments.length < 3) {
                continue; // ignore irregular lines
            }

            String timestamp = segments[0];
            String sender = segments[1];
            String message = segments[2];

            if (message.toLowerCase().contains(term)) {
                matches++;
                builder.append(timestamp)
                       .append(" ")
                       .append(sender)
                       .append(": ")
                       .append(message)
                       .append("\n");
            }
        }

        System.out.println("Matches: " + matches);
        System.out.print(builder.toString());
        scanner.close();
    }
}