enum TransactionType {
    DEPOSIT, WITHDRAW, TRANSFER
}

record Command(TransactionType type, String accountNumber, long amount) {}

class Validator {
    public static boolean isValidMobile(String s) {
        if (s == null || s.length() != 10) return false;
        char first = s.charAt(0);
        if (first < '6' || first > '9') return false;

        for (int i = 0; i < s.length(); i++) {
            if (s.charAt(i) < '0' || s.charAt(i) > '9') return false;
        }
        return true;
    }

    public static boolean isValidPan(String s) {
        if (s == null || s.length() != 10) return false;
        for (int i = 0; i < 5; i++) {
            if (s.charAt(i) < 'A' || s.charAt(i) > 'Z') return false;
        }
        for (int i = 5; i < 9; i++) {
            if (s.charAt(i) < '0' || s.charAt(i) > '9') return false;
        }
        char last = s.charAt(9);
        return last >= 'A' && last <= 'Z';
    }
}

class CommandParser {
    public static Command parse(String line) {
        String[] parts = line.split(" ");
        TransactionType type = TransactionType.valueOf(parts[0].toUpperCase());
        String accNum = parts[1];
        long amt = Long.parseLong(parts[2]);
        return new Command(type, accNum, amt);
    }
}

class StatementFormatter {
    public static String buildStatement(String accNum, String name, long balance) {
        StringBuilder sb = new StringBuilder();
        sb.append("=========================\n");
        sb.append("Account: ").append(accNum).append("\n");
        sb.append("Holder : ").append(name).append("\n");
        sb.append("Balance: ").append(balance).append("\n");
        sb.append("=========================");
        return sb.toString();
    }
}

public class MiniBankPartB {
    public static void main(String[] args) {
        System.out.println("Checking 9876543210: " + Validator.isValidMobile("9876543210"));
        System.out.println("Checking 12345: " + Validator.isValidMobile("12345"));

        Command command = CommandParser.parse("DEPOSIT AC0001 500");
        System.out.println("Parsed: " + command.type() + " on " + command.accountNumber() + " with amount " + command.amount());

        System.out.println(StatementFormatter.buildStatement("AC0001", "Riya", 5500));
    }
}