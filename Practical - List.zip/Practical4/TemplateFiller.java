public class TemplateFiller {
    public static void main(String[] args) {
        String template = "Dear {name}, order {id} ships {date}.";
        String[] keys = {"name", "id"};
        String[] vals = {"Riya", "A07"};

        StringBuilder output = new StringBuilder();
        int i = 0;

        while (i < template.length()) {
            if (template.charAt(i) == '{') {
                int closingIndex = template.indexOf('}', i);
                if (closingIndex != -1) {
                    String placeholder = template.substring(i + 1, closingIndex);
                    String replacement = "[?]";

                    for (int k = 0; k < keys.length; k++) {
                        if (keys[k].equals(placeholder)) {
                            replacement = vals[k];
                            break;
                        }
                    }

                    output.append(replacement);
                    i = closingIndex + 1;
                    continue;
                }
            }
            output.append(template.charAt(i));
            i++;
        }

        System.out.println(output.toString());
    }
}