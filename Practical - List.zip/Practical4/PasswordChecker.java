public class PasswordChecker {
    public static String strength(String password) {
        int passed = 0;

        boolean ruleLen = password.length() >= 8;
        boolean hasUpper = false;
        boolean hasDigit = false;
        boolean hasSpecial = false;

        for (int i = 0; i < password.length(); i++) {
            char ch = password.charAt(i);
            if (ch >= 'A' && ch <= 'Z') hasUpper = true;
            else if (ch >= '0' && ch <= '9') hasDigit = true;
            else if (ch < 'a' || ch > 'z') hasSpecial = true;
        }

        if (ruleLen) passed++;
        if (hasUpper) passed++;
        if (hasDigit) passed++;
        if (hasSpecial) passed++;

        System.out.println("Password '" + password + "' passed rules: " + passed + "/4");

        if (passed <= 1) return "Weak";
        if (passed <= 3) return "Medium";
        return "Strong";
    }

    public static void main(String[] args) {
        System.out.println("Verdict: " + strength("abc"));
        System.out.println("Verdict: " + strength("Abcd1234!"));
    }
}