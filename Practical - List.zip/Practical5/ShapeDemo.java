abstract class Shape {
    abstract double area();
}

class Circle extends Shape {
    double radius;
    Circle(double radius) { this.radius = radius; }
    double area() { return 3.14159 * radius * radius; }
}

class Rectangle extends Shape {
    double width, height;
    Rectangle(double width, double height) {
        this.width = width;
        this.height = height;
    }
    double area() { return width * height; }
}

class Triangle extends Shape {
    double base, height;
    Triangle(double base, double height) {
        this.base = base;
        this.height = height;
    }
    double area() { return 0.5 * base * height; }
}

public class ShapeDemo {
    public static void main(String[] args) {
        Shape[] shapes = {
            new Circle(3.0),
            new Rectangle(4.0, 5.0),
            new Triangle(3.0, 4.0)
        };

        double totalArea = 0;
        double maxArea = 0;

        for (int i = 0; i < shapes.length; i++) {
            double currentArea = shapes[i].area();
            System.out.println("Area: " + currentArea);
            totalArea = totalArea + currentArea;
            if (currentArea > maxArea) {
                maxArea = currentArea;
            }
        }

        System.out.println("Total Area: " + totalArea);
        System.out.println("Largest Area: " + maxArea);
    }
}