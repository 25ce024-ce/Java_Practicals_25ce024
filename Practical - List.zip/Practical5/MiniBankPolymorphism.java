abstract class Account {
    private String accountNumber;
    private String ownerName;
    protected long balance;

    public Account(String accountNumber, String ownerName, long balance) {
        this.accountNumber = accountNumber;
        this.ownerName = ownerName;
        this.balance = balance;
    }

    public abstract double interestRate();
    public abstract boolean canWithdraw(long amount);

    public String getAccountNumber() { return accountNumber; }
    public String getOwnerName() { return ownerName; }
    public long getBalance() { return balance; }
}

class SavingsAccount extends Account {
    private long minBalance;

    public SavingsAccount(String accNum, String name, long balance, long minBalance) {
        super(accNum, name, balance);
        this.minBalance = minBalance;
    }

    public double interestRate() { return 4.0; }
    public boolean canWithdraw(long amount) {
        return (balance - amount) >= minBalance;
    }
}

class CurrentAccount extends Account {
    private long overdraftLimit;

    public CurrentAccount(String accNum, String name, long balance, long overdraftLimit) {
        super(accNum, name, balance);
        this.overdraftLimit = overdraftLimit;
    }

    public double interestRate() { return 0.0; }
    public boolean canWithdraw(long amount) {
        return (balance - amount) >= -overdraftLimit;
    }
}

class FixedDepositAccount extends Account {
    public FixedDepositAccount(String accNum, String name, long balance) {
        super(accNum, name, balance);
    }

    public double interestRate() { return 7.0; }
    public boolean canWithdraw(long amount) {
        return false; // locked deposit
    }
}

public class MiniBankPolymorphism {
    public static void main(String[] args) {
        Account[] accounts = {
            new SavingsAccount("SA01", "Riya", 10000, 1000),
            new CurrentAccount("CA01", "Tech Corp", 20000, 5000),
            new FixedDepositAccount("FD01", "Sunil", 50000)
        };

        for (int i = 0; i < accounts.length; i++) {
            Account acc = accounts[i];
            System.out.println(acc.getAccountNumber() + " Rate: " + acc.interestRate() + "%");

            if (acc instanceof SavingsAccount sa) {
                System.out.println("  -> Savings test: Can withdraw 9500? " + sa.canWithdraw(9500));
            }
        }
    }
}