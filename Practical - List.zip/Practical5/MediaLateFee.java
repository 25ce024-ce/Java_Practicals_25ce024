abstract class Media {
    String title;
    int daysLate;

    Media(String title, int daysLate) {
        this.title = title;
        this.daysLate = daysLate;
    }

    abstract double calculateFee();
}

class Book extends Media {
    Book(String title, int daysLate) { super(title, daysLate); }
    double calculateFee() { return daysLate * 2.0; }
}

class DVD extends Media {
    DVD(String title, int daysLate) { super(title, daysLate); }
    double calculateFee() { return daysLate * 5.0; }
}

public class MediaLateFee {
    public static void main(String[] args) {
        Media[] borrowed = {
            new Book("Core Java", 4),
            new DVD("Inception", 2)
        };

        double total = 0;
        for (int i = 0; i < borrowed.length; i++) {
            double fee = borrowed[i].calculateFee();
            total = total + fee;
            System.out.println(borrowed[i].title + " Fee: " + fee);
        }
        System.out.println("Total Dues: " + total);
    }
}