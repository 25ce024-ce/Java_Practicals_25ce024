abstract class Employee {
    String id;
    String name;

    Employee(String id, String name) {
        this.id = id;
        this.name = name;
    }

    abstract double monthlySalary();
}

class FullTime extends Employee {
    double fixedSalary;
    FullTime(String id, String name, double fixedSalary) {
        super(id, name);
        this.fixedSalary = fixedSalary;
    }
    double monthlySalary() { return fixedSalary; }
}

class PartTime extends Employee {
    int hours;
    double hourlyRate;
    PartTime(String id, String name, int hours, double hourlyRate) {
        super(id, name);
        this.hours = hours;
        this.hourlyRate = hourlyRate;
    }
    double monthlySalary() { return hours * hourlyRate; }
}

class Intern extends Employee {
    double stipend;
    Intern(String id, String name, double stipend) {
        super(id, name);
        this.stipend = stipend;
    }
    double monthlySalary() { return stipend; }
}

public class PayrollDemo {
    public static void main(String[] args) {
        Employee[] staff = {
            new FullTime("E01", "Alice", 60000),
            new PartTime("E02", "Bob", 40, 500),
            new Intern("E03", "Charlie", 15000)
        };

        double totalPayroll = 0;
        for (int i = 0; i < staff.length; i++) {
            double sal = staff[i].monthlySalary();
            totalPayroll = totalPayroll + sal;

            System.out.print(staff[i].name + " Salary: " + sal);
            if (staff[i] instanceof Intern) {
                System.out.print(" (Intern Note: Under Review)");
            }
            System.out.println();
        }

        System.out.println("Total Payroll: " + totalPayroll);
    }
}