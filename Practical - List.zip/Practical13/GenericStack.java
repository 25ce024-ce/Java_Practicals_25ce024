import java.util.*;

class SimpleStack<T> {
    private ArrayList<T> values = new ArrayList<>();

    void push(T value) {
        values.add(value);
    }

    T pop() {
        if (values.isEmpty()) {
            return null;
        }
        return values.remove(values.size() - 1);
    }
}

public class GenericStack {
    public static void main(String[] args) {
        SimpleStack<Integer> numbers = new SimpleStack<>();
        numbers.push(10);
        numbers.push(20);
        System.out.println(numbers.pop());

        SimpleStack<String> names = new SimpleStack<>();
        names.push("Riya");
        names.push("Aman");
        System.out.println(names.pop());
    }
}
