import java.lang.annotation.*;
import java.lang.reflect.*;
import java.util.*;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
@interface Id {}

class Account {
    @Id
    private String accountNumber;
    private String owner;
    private long balance;

    Account(String accountNumber, String owner, long balance) {
        this.accountNumber = accountNumber;
        this.owner = owner;
        this.balance = balance;
    }

    public String toString() {
        return accountNumber + " | " + owner + " | " + balance;
    }
}

class Repository<T> {
    private HashMap<String, T> data = new HashMap<>();

    T save(T entity) {
        try {
            for (Field field : entity.getClass().getDeclaredFields()) {
                if (field.isAnnotationPresent(Id.class)) {
                    field.setAccessible(true);
                    String id = field.get(entity).toString();
                    data.put(id, entity);
                    return entity;
                }
            }
            throw new IllegalArgumentException("No @Id field found");
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        }
    }

    @SafeVarargs
    final void saveAll(T... items) {
        for (T item : items) {
            save(item);
        }
    }

    T findById(String id) {
        return data.get(id);
    }

    ArrayList<T> findAll() {
        return new ArrayList<>(data.values());
    }

    boolean delete(String id) {
        return data.remove(id) != null;
    }

    static <N extends Number> double average(N[] values) {
        double total = 0;
        for (N value : values) {
            total += value.doubleValue();
        }
        return total / values.length;
    }
}

public class RepositoryDemo {
    public static void main(String[] args) {
        Repository<Account> repository = new Repository<>();
        repository.saveAll(
            new Account("AC0001", "Riya", 5000),
            new Account("AC0002", "Aman", 2000),
            new Account("AC0003", "Jay", 9000)
        );

        System.out.println(repository.findById("AC0002"));
        for (Account account : repository.findAll()) {
            System.out.println(account);
        }

        Integer[] values = {10, 20, 30};
        System.out.println("Average: " + Repository.average(values));
    }
}
