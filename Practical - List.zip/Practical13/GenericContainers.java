class Box<T> {
    private T value;

    void set(T value) {
        this.value = value;
    }

    T get() {
        return value;
    }
}

class Pair<A, B> {
    A first;
    B second;

    Pair(A first, B second) {
        this.first = first;
        this.second = second;
    }
}

public class GenericContainers {
    static <T> T first(T[] values) {
        return values[0];
    }

    public static void main(String[] args) {
        Box<String> box = new Box<>();
        box.set("Hello Java");
        System.out.println(box.get());

        Pair<String, Integer> pair = new Pair<>("Age", 20);
        System.out.println(pair.first + ": " + pair.second);

        Integer[] numbers = {10, 20, 30};
        System.out.println(first(numbers));
    }
}
