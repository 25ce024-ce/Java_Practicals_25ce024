import java.util.*;

public class WordFrequency {
    public static void main(String[] args) {
        String sentence = "java is fun and java is useful";
        Map<String, Integer> count = new HashMap<>();

        for (String word : sentence.split(" ")) {
            count.put(word, count.getOrDefault(word, 0) + 1);
        }

        List<Map.Entry<String, Integer>> words = new ArrayList<>(count.entrySet());
        words.sort((a, b) -> b.getValue().compareTo(a.getValue()));

        for (Map.Entry<String, Integer> entry : words) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }
    }
}
