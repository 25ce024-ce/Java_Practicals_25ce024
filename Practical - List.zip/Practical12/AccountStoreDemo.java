import java.util.*;
import java.util.concurrent.*;

class StoredAccount implements Comparable<StoredAccount> {
    String number;
    String owner;
    long balance;

    StoredAccount(String number, String owner, long balance) {
        this.number = number;
        this.owner = owner;
        this.balance = balance;
    }

    public int compareTo(StoredAccount other) {
        return number.compareTo(other.number);
    }

    public String toString() {
        return number + " | " + owner + " | " + balance;
    }
}

class AccountStore {
    private HashMap<String, StoredAccount> accounts = new HashMap<>();
    private ArrayList<String> history = new ArrayList<>();

    void add(StoredAccount account) {
        accounts.put(account.number, account);
        history.add("Added " + account.number);
    }

    StoredAccount get(String number) {
        return accounts.get(number);
    }

    ArrayList<StoredAccount> getAll() {
        return new ArrayList<>(accounts.values());
    }

    ArrayList<StoredAccount> sortedByBalance() {
        ArrayList<StoredAccount> list = getAll();
        list.sort(Comparator.comparingLong((StoredAccount a) -> a.balance).reversed());
        return list;
    }
}

public class AccountStoreDemo {
    public static void main(String[] args) {
        AccountStore store = new AccountStore();
        store.add(new StoredAccount("AC0001", "Riya", 5000));
        store.add(new StoredAccount("AC0002", "Aman", 2000));
        store.add(new StoredAccount("AC0003", "Jay", 9000));

        System.out.println(store.get("AC0002"));
        for (StoredAccount account : store.sortedByBalance()) {
            System.out.println(account);
        }

        ConcurrentHashMap<String, StoredAccount> safeAccounts = new ConcurrentHashMap<>();
        for (StoredAccount account : store.getAll()) {
            safeAccounts.put(account.number, account);
        }
        System.out.println("Thread-safe account count: " + safeAccounts.size());
    }
}
