class LockAccount {
    int balance;
    final int number;

    LockAccount(int number, int balance) {
        this.number = number;
        this.balance = balance;
    }
}

public class DeadlockFix {
    static void transfer(LockAccount a, LockAccount b, int amount) {
        LockAccount first = a.number < b.number ? a : b;
        LockAccount second = a.number < b.number ? b : a;

        synchronized (first) {
            synchronized (second) {
                a.balance -= amount;
                b.balance += amount;
                System.out.println("Transfer completed");
            }
        }
    }

    public static void main(String[] args) throws InterruptedException {
        LockAccount a = new LockAccount(1, 1000);
        LockAccount b = new LockAccount(2, 1000);

        Thread one = new Thread(() -> transfer(a, b, 100));
        Thread two = new Thread(() -> transfer(b, a, 50));

        one.start();
        two.start();
        one.join();
        two.join();

        System.out.println("A: " + a.balance);
        System.out.println("B: " + b.balance);
    }
}
