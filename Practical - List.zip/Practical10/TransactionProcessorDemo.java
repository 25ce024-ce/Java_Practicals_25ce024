import java.util.concurrent.*;

class TransactionProcessor {
    private ExecutorService pool = Executors.newFixedThreadPool(4);

    void submit(Runnable task) {
        pool.execute(task);
    }

    void stop() throws InterruptedException {
        pool.shutdown();
        pool.awaitTermination(1, TimeUnit.MINUTES);
    }
}

public class TransactionProcessorDemo {
    public static void main(String[] args) throws InterruptedException {
        TransactionProcessor processor = new TransactionProcessor();

        for (int i = 1; i <= 10; i++) {
            int id = i;
            processor.submit(() -> System.out.println("Transaction " + id + " processed"));
        }

        processor.stop();
        System.out.println("Processor stopped");
    }
}
