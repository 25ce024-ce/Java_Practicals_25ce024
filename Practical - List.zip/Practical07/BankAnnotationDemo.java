import java.lang.annotation.*;
import java.lang.reflect.*;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
@interface Id {}

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
@interface Positive {
    String message() default "must be > 0";
}

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
@interface MaxLength {
    int value();
}

class BankAccount {
    @Id
    private String accountNumber;

    @Positive
    private long balance;

    @MaxLength(20)
    private String owner;

    BankAccount(String accountNumber, long balance, String owner) {
        this.accountNumber = accountNumber;
        this.balance = balance;
        this.owner = owner;
    }
}

class AnnotationValidator {
    public static String[] validate(Object obj) throws IllegalAccessException {
        java.util.ArrayList<String> errors = new java.util.ArrayList<>();

        for (Field field : obj.getClass().getDeclaredFields()) {
            field.setAccessible(true);
            Object value = field.get(obj);

            if (field.isAnnotationPresent(Positive.class) && value instanceof Number) {
                if (((Number) value).longValue() <= 0) {
                    errors.add(field.getName() + ": " + field.getAnnotation(Positive.class).message());
                }
            }

            if (field.isAnnotationPresent(MaxLength.class) && value != null) {
                int max = field.getAnnotation(MaxLength.class).value();
                if (value.toString().length() > max) {
                    errors.add(field.getName() + ": maximum length is " + max);
                }
            }
        }

        return errors.toArray(new String[0]);
    }
}

public class BankAnnotationDemo {
    public static void main(String[] args) throws Exception {
        BankAccount account = new BankAccount("AC0001", -100, "Riya");
        String[] errors = AnnotationValidator.validate(account);

        for (String error : errors) {
            System.out.println(error);
        }
    }
}
