import java.lang.annotation.*;
import java.lang.reflect.*;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
@interface Run {}

class SampleTests {
    @Run
    public void testOne() {
        System.out.println("Test one passed");
    }

    @Run
    public void testTwo() {
        System.out.println("Test two passed");
    }

    public void helper() {
        System.out.println("This method is not a test");
    }
}

public class MiniTestRunner {
    public static void main(String[] args) throws Exception {
        SampleTests tests = new SampleTests();
        int count = 0;

        for (Method method : tests.getClass().getDeclaredMethods()) {
            if (method.isAnnotationPresent(Run.class)) {
                method.invoke(tests);
                count++;
            }
        }

        System.out.println("Tests run: " + count);
    }
}
