import java.lang.annotation.*;
import java.lang.reflect.*;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
@interface Column {
    String name();
}

class Student {
    @Column(name = "name")
    String name;

    @Column(name = "age")
    int age;

    public String toString() {
        return name + " " + age;
    }
}

public class ColumnMapper {
    public static void main(String[] args) throws Exception {
        String[] headers = {"name", "age"};
        String[] values = {"Riya", "20"};
        Student student = new Student();

        for (Field field : Student.class.getDeclaredFields()) {
            if (field.isAnnotationPresent(Column.class)) {
                String columnName = field.getAnnotation(Column.class).name();

                for (int i = 0; i < headers.length; i++) {
                    if (headers[i].equals(columnName)) {
                        field.setAccessible(true);
                        if (field.getType() == int.class) {
                            field.setInt(student, Integer.parseInt(values[i]));
                        } else {
                            field.set(student, values[i]);
                        }
                    }
                }
            }
        }

        System.out.println(student);
    }
}
