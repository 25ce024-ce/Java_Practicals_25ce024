import java.util.Scanner;

record Vehicle(String number, String type) {}

public class TollBooth {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int totalToll = 0;
        int bikeCount = 0;
        int carCount = 0;
        int truckCount = 0;

        while (true) {
            System.out.print("Enter vehicle number (or 'done' to stop): ");
            String plateNumber = scanner.next();

            if (plateNumber.equalsIgnoreCase("done")) {
                break;
            }

            System.out.print("Enter vehicle type (bike/car/truck): ");
            String category = scanner.next().toLowerCase();

            Vehicle vehicle = new Vehicle(plateNumber, category);

            int fee = switch (vehicle.type()) {
                case "bike" -> {
                    bikeCount++;
                    yield 20;
                }
                case "car" -> {
                    carCount++;
                    yield 50;
                }
                case "truck" -> {
                    truckCount++;
                    yield 150;
                }
                default -> 0;
            };

            totalToll = totalToll + fee;
        }

        System.out.println("Total toll: " + totalToll);

        String popularType = "bike";
        int highestVisits = bikeCount;

        if (carCount > highestVisits) {
            popularType = "car";
            highestVisits = carCount;
        }
        if (truckCount > highestVisits) {
            popularType = "truck";
        }

        System.out.println("Most frequent: " + popularType);
        scanner.close();
    }
}