import java.util.Scanner;

enum Move {
    ROCK, PAPER, SCISSORS, LIZARD, SPOCK
}

public class RPSLS {
    static int winner(Move user, Move computer) {
        if (user == computer) {
            return 0; // tie
        }

        return switch (user) {
            case SCISSORS -> (computer == Move.PAPER || computer == Move.LIZARD) ? 1 : -1;
            case PAPER -> (computer == Move.ROCK || computer == Move.SPOCK) ? 1 : -1;
            case ROCK -> (computer == Move.LIZARD || computer == Move.SCISSORS) ? 1 : -1;
            case LIZARD -> (computer == Move.SPOCK || computer == Move.PAPER) ? 1 : -1;
            case SPOCK -> (computer == Move.SCISSORS || computer == Move.ROCK) ? 1 : -1;
        };
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Move[] moves = Move.values();

        int userWins = 0;
        int compWins = 0;

        for (int round = 1; round <= 5; round++) {
            System.out.println("\nRound " + round);

            // Pseudo-random selection using basic system time
            int randomIndex = (int) (System.currentTimeMillis() % moves.length);
            Move compMove = moves[randomIndex];

            System.out.print("Pick (ROCK, PAPER, SCISSORS, LIZARD, SPOCK): ");
            String rawInput = scanner.next().toUpperCase();
            Move userMove = Move.valueOf(rawInput);

            System.out.println("Computer chose: " + compMove);
            int outcome = winner(userMove, compMove);

            if (outcome == 1) {
                System.out.println("Result: You win this round!");
                userWins++;
            } else if (outcome == -1) {
                System.out.println("Result: Computer wins this round!");
                compWins++;
            } else {
                System.out.println("Result: Round tied!");
            }
        }

        System.out.println("\n--- Summary ---");
        if (userWins > compWins) {
            System.out.println("You win " + userWins + "-" + compWins);
        } else if (compWins > userWins) {
            System.out.println("Computer wins " + compWins + "-" + userWins);
        } else {
            System.out.println("Tied " + userWins + "-" + compWins);
        }

        scanner.close();
    }
}