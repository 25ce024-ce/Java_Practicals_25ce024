import java.util.Scanner;

abstract class Shape {
abstract double area();
}

class Circle extends Shape {
double r;


Circle(double r) {
    this.r = r;
}

double area() {
    return 3.14159 * r * r;
}

}

class Rectangle extends Shape {
double w, h;


Rectangle(double w, double h) {
    this.w = w;
    this.h = h;
}

double area() {
    return w * h;
}


}

class Triangle extends Shape {
double b, h;


Triangle(double b, double h) {
    this.b = b;
    this.h = h;
}

double area() {
    return 0.5 * b * h;
}


}

enum Coin {
ONE, TWO, FIVE, TEN
}

public class VendingMachine {
public static void main(String[] args) {
Scanner scanner = new Scanner(System.in);


    int targetPrice = 15;
    int currentTotal = 0;

    while (currentTotal < targetPrice) {
        System.out.print("Insert coin (ONE, TWO, FIVE, TEN): ");

        String input = scanner.next().toUpperCase();
        Coin coin = Coin.valueOf(input);

        int value = switch (coin) {
            case ONE -> 1;
            case TWO -> 2;
            case FIVE -> 5;
            case TEN -> 10;
        };

        currentTotal += value;

        System.out.println("Running total: " + currentTotal);
    }

    int change = currentTotal - targetPrice;

    System.out.println("Paid. Change: " + change);

    scanner.close();
}


}
