import java.util.Scanner;

record BankInfo(String name, String branch) {}

enum MenuOption {
    OPEN_ACCOUNT, DEPOSIT, WITHDRAW, TRANSFER, EXIT
}

public class MiniBank {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        BankInfo info = new BankInfo("MiniBank", "Main Branch");

        boolean keepRunning = true;

        while (keepRunning) {
            System.out.println("\n=================================");
            System.out.println(info.name() + " (" + info.branch() + ")");
            System.out.println("=================================");
            System.out.println("1. Open Account");
            System.out.println("2. Deposit");
            System.out.println("3. Withdraw");
            System.out.println("4. Transfer");
            System.out.println("5. Exit");
            System.out.print("Choose an option (1-5): ");

            int selection = scanner.nextInt();

            MenuOption choice = switch (selection) {
                case 1 -> MenuOption.OPEN_ACCOUNT;
                case 2 -> MenuOption.DEPOSIT;
                case 3 -> MenuOption.WITHDRAW;
                case 4 -> MenuOption.TRANSFER;
                case 5 -> MenuOption.EXIT;
                default -> null;
            };

            if (choice == null) {
                System.out.println("Invalid number! Please choose between 1 and 5.");
                continue;
            }

            switch (choice) {
                case OPEN_ACCOUNT -> System.out.println("Placeholder: Account opening feature coming soon.");
                case DEPOSIT -> System.out.println("Placeholder: Deposit feature coming soon.");
                case WITHDRAW -> System.out.println("Placeholder: Withdraw feature coming soon.");
                case TRANSFER -> System.out.println("Placeholder: Transfer feature coming soon.");
                case EXIT -> {
                    System.out.println("Exiting application. Goodbye!");
                    keepRunning = false;
                }
            }
        }

        scanner.close();
    }
}